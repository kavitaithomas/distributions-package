# shortcut to import Gaussian and Binomial classes

from .GaussianDistribution import Gaussian
from .BinomialDistribution import Binomial